CHANZ EDITZ WEBSITE
1. Upload index.html, style.css, and script.js to your web hosting.
2. Set index.html as the homepage.
3. The WhatsApp buttons use the link provided in the brief.
4. Replace the portfolio placeholder cards with your own images/videos when ready.
